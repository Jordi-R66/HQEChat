﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace STIChat {
	class Client {
		readonly IPEndPoint ClientEndPoint;
		readonly IPAddress TargetIpObj;

		public Client(string ip, ushort port) {
			TargetIpObj = IPAddress.Parse(ip);

			ClientEndPoint = new(TargetIpObj, port);
		}

		public void Run() {
			using TcpClient client = new();
			 client.Connect(ClientEndPoint);
			 using NetworkStream stream = client.GetStream();

			byte[] buffer = new byte[1024];
			int received = stream.Read(buffer);

			string message = Encoding.UTF8.GetString(buffer, 0, received);
			Console.WriteLine($"Message reçu : {message}");
		}
	}
}
