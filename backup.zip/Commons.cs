﻿using System.Text;

namespace STIChat {
	static public class Constantes {
		static public readonly string eom_sequence = "<|EOM|>";
		static public readonly string ack_sequence = "<|ACK|>";
		static public readonly byte[] ackBytes = Encoding.UTF8.GetBytes(ack_sequence);
	}
}
