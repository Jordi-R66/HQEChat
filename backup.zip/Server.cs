﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace STIChat {
	public class Server {
		readonly IPEndPoint ServerEndPoint;
		readonly IPAddress ServerIpObj;

		public Server(string ip, ushort port) {
			ServerIpObj = IPAddress.Parse(ip);
			ServerEndPoint = new(ServerIpObj, port);
		}

		public void Run() {
			TcpListener listener = new(ServerEndPoint);

			try {
				listener.Start();

				using TcpClient handler = listener.AcceptTcpClient();
				using NetworkStream stream = handler.GetStream();

				string message = $"{DateTime.UtcNow}";
				byte[] dateTimeBytes = Encoding.UTF8.GetBytes(message);
				stream.Write(dateTimeBytes);

				Console.WriteLine($"Message envoyé : {message}");
			} finally {
				listener.Stop();
			}
		}
	}
}
