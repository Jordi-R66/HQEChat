﻿namespace STIChat {
	static internal class Program {
		 public static void Main() {
			Console.Write("S : Créer un serveur\nC : Se connecter à un serveur\n\nTapez la lettre associée à votre choix : ");
			int answer = Console.Read();

			if (( answer == 'c' ) || ( answer == 'C' )) {
				Client MyClient = new("192.168.1.104", 11_107);
				MyClient.Run();
			} else if (( answer == 's' ) || ( answer == 'S' )) {
				Server MyServer = new("192.168.1.104", 11_107);
				MyServer.Run();
			}
		}
	}
}